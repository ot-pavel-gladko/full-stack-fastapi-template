# Workshop: Implement a Feature with the Agentic Development Lifecycle (ADLC)

**Level:** 02-advanced
**Duration:** ~2.5–3 hours (resumable across sessions)
**Prerequisites:** The **configure-workspace-kb-and-agents** workshop completed — a configured workspace with **7 agents** (incl. the **design** agent and the **lead with Jira read+transition**), a working Jira PAT, and ≥1 repo checked out.
**Date:** 2026-06-17

---

## Overview

You implement one real product feature **end to end** with a team of agents —
**design-first** (wireframe → requirements → implementation) — acting as the
**human at every decision gate** yourself (Product Owner, BA reviewer, Tech-lead).
Agents do the production work; you review, decide, and unblock.

**Learning outcomes:** human-in-the-loop agentic delivery; **multi-agent
orchestration** across different tool scopes (and how the lead bridges them);
**state-driven resumability** via a persistent feature manifest; **per-run
isolation** in a shared Jira + repo.

> The full welcome and the *why* behind each part are presented live at the
> **Orientation** step — this overview is only the catalog summary.

---

## The feature you'll build (sample task)

> **Add a time-tracking feature to the full-stack-fastapi-template application.**
> Users can create **projects**, log **time entries** against them (date, hours,
> description, billable flag), and view a **dashboard** summarizing hours worked.
> Follow the existing **Items module** patterns — backend (SQLModel, FastAPI CRUD,
> Alembic migrations) and frontend (TanStack Router/Query, React Hook Form,
> shadcn/ui). **Keep it simple:** no approval workflows, invoicing, CSV export, or
> timer/stopwatch.

Two new entities (**Project**, **TimeEntry**) + a summary dashboard — enough to
exercise backend, frontend, and a wireframe.

---

## Prerequisites

**Required:**
- The **configure-workspace-kb-and-agents** workshop finished — verify with `artisyn-workspace status` (≥13/15) and that `.claude/agents/` has **7** agents including `<WS>-design`.
- The lead agent has Jira **read + transition** tools; the BA has the Jira **author** set.
- `JIRA_PERSONAL_TOKEN` + `JIRA_USERNAME` set in `.env`; Jira reachable.
- **Access to the `TRRND` Jira project** — this workshop is hard-wired to it. No access → **contact the workshop org team to get access to the TRRND project** (the pre-flight gate enforces this).
- A clean repo checkout under `../src` on its **default branch** (`master` or `main` — the workshop auto-detects it), and the ability to **push** to it.

**Recommended:**
- Familiarity with the repo's Items module (the patterns you'll mirror).

**Setup:**
- `source .venv/bin/activate`; confirm `git`, `uvx`, and the GitHub MCP are working.
- Restart Claude Code once so the Jira MCP server is connected (`/mcp` shows `atlassian-da-jira`).

---

## Conventions & placeholders

Run by many people against the **same** Jira and repo — so everything is scoped
per-run. Substitute `<…>` with your values.

| Placeholder | Meaning | Source |
|---|---|---|
| `<WS>` | Your workspace agent prefix | the `name=` prefix in `.claude/agents/` |
| `<repo>` | Repo dir name | the folder under `../src/` |
| `RUN_ID` | Your unique run id | `<jira-username>-<YYYYMMDD-HHMMSS>-<rand>` (auto-derived at Step 0; seconds + random ⇒ collision-proof for parallel runs) |
| `PROJECT_KEY` | Jira project for the epic/stories | **fixed: `TRRND`** — this workshop is hard-wired to it (not configurable) |
| `<EPIC_KEY>` | The epic's Jira key | assigned by Jira when the epic is created (e.g. `TRRND-2`) |
| `<feature-slug>` | kebab-case of the feature name | `time-tracking` |

> All commands run from your **workspace root**. The repo working copy is under `../src/<repo>`.

### Naming conventions (standardized — used by every run)

Everything a run creates follows a fixed naming scheme so it's unique, identifiable,
and groupable in the shared Jira + repo:

| Artifact | Template | Example |
|----------|----------|---------|
| **Git feature branch** | `feature/<EPIC_KEY>-<feature-slug>` | `feature/TRRND-2-time-tracking` |
| **Jira Epic** (summary) | `[ADLC <RUN_ID>] <Feature Name>` | `[ADLC pgladko-20260626-142530-9c1f] Time tracking` |
| **Jira Story** (summary) | `[ADLC <RUN_ID>] [<AREA>] <Story title>` | `[ADLC pgladko-20260626-142530-9c1f] [BE] Project model + CRUD` |
| **Label** (epic + every story) | `run-<RUN_ID>` | `run-pgladko-20260626-142530-9c1f` |

- **`<AREA>`** ∈ `BE` (backend) · `FE` (frontend) · `WF` (wireframe).
- Every issue carries the **`[ADLC <RUN_ID>]`** stamp (human-visible grouping) **and**
  the `run-<RUN_ID>` **label** (machine filter: `jira_search 'labels = run-<RUN_ID>'`).
- The branch is unique because `<EPIC_KEY>` is; `<feature-slug>` is the feature name
  lowercased with spaces → hyphens.

---

## How this workshop runs

A **guided, hands-on, design-first** workshop facilitated by you (or the
`workshop-executor` skill):

1. **Why first.** Every step opens with **Why this matters** — read it before acting.
2. **You are the human at every gate** — Product Owner (wireframe), BA reviewer (requirements), Tech-lead (code). The agents do the production work; you review and decide.
3. **You observe the orchestration.** When the lead delegates, you see *what* it passes to which agent and *why* — that transparency is the lesson.
4. **Stop anytime at a gate.** Sessions break at human reviews; the feature manifest lets you resume later from exactly where you left off.
5. **Sessions run consecutively, never in parallel** — each depends on the last (requirements depend on the approved design; implementation depends on Ready-for-Dev stories).

> **Facilitator note (incl. `workshop-executor`):** present each step's **Why this
> matters**, the delegation brief, and **Checkpoint** verbatim; pause for the
> learner to review/decide at every human gate; never approve on the learner's behalf.
> `💡 Think about it` lines are **non-blocking** — present them, but don't wait for
> an answer.

### Running it again (a second pass)

You can take this workshop more than once — each pass is a **fresh, fully isolated
run**: a new `RUN_ID`, a new epic + stories, and a new `feature/<EPIC_KEY>-<slug>`
branch. **Your previous run is left completely intact** (its epic, branch, PR, and
manifest are untouched and never mixed in).

- **Before starting again, reset to a clean default branch:**
  ```bash
  cd ../src/<repo> && git checkout "$BASE_BRANCH" && git pull --ff-only
  ```
  The Pre-flight gate requires the repo to be **on its default branch with a clean
  tree** — after a prior run you're sitting on that run's feature branch, so switch
  back (commit/stash anything outstanding first).
- **Fresh pass vs. resume:**
  - On the **default branch → run Pre-flight** = a brand-new run (new RUN_ID/epic/branch).
  - On an **in-progress feature branch** = *resume* that run (its `.adlc/feature.json` continues it).
- Re-running the **same sample feature** just creates a *second* epic for it — expected in a shared training project; both runs coexist, isolated by their RUN_IDs.

### Resuming a run (continue where you stopped)

Everything needed to continue lives **in the manifest on your feature branch** —
not in any chat session. To resume:

```bash
cd ../src/<repo>
git branch --all --list '*feature/*'          # forgot your branch? it's feature/<EPIC_KEY>-<slug>
git checkout feature/<EPIC_KEY>-<feature-slug> && git pull
python3 -m json.tool .adlc/feature.json       # your run's full state
```

Restore your context **from the manifest** — `run_id`, `epic_key`, `branch`,
`base_branch`, `stories`, `current_step` — and continue at the step **after**
`current_step`. Agents must take these values from the manifest, never from memory
or broad searches (isolation rule 3).

---

## Concepts (read first — the machinery, and why)

**The feature manifest — `.adlc/feature.json` (state-driven resumability).**
A small JSON file committed to the feature branch that *is* the source of truth for
the run. Any session reads it to know where you are. *Why: a chat session's context
evaporates; the feature's own persisted state does not — so you (or a teammate) can
resume next week.*
```json
{
  "run_id": "pgladko-20260626-142530-9c1f",
  "project_key": "TRRND",
  "epic_key": "TRRND-512",
  "feature": "Time tracking",
  "feature_slug": "time-tracking",
  "base_branch": "master",
  "branch": "feature/TRRND-512-time-tracking",
  "current_step": 3,
  "timeline": { "0": "2026-06-26T12:25:30Z", "2": "2026-06-26T13:02:11Z" },
  "stories": ["TRRND-513", "…"],
  "artifacts": { "wireframe": "wireframes/TRRND-512.html", "brief": null, "pr": null },
  "reviews": []
}
```
*Whoever advances `current_step` also stamps an ISO-UTC timestamp into `timeline`
— after a few runs those measure the real per-session durations (used to
recalibrate this workshop's stated duration).*

**Run isolation — hard rules (many people run this in parallel against the *same*
Jira project and repo, creating issues and coding simultaneously).** Each run has a
unique `RUN_ID`, an epic-key-derived branch, and a `run-<RUN_ID>` label on every
issue. To **guarantee** one run never sees or touches another's work, agents MUST
follow these rules — they are not optional:

1. **Every Jira read is run-scoped.** Every `jira_search` includes
   `labels = run-<RUN_ID>` (or `"Epic Link" = <EPIC_KEY>`). **Never** run a bare
   `project = TRRND` search — it returns *everyone's* issues, which is exactly the
   leak we're preventing.
2. **Verify ownership before any write.** Before `jira_transition_issue` /
   `jira_update_issue` / `jira_add_comment`, confirm the target issue belongs to
   **this** run — its key is the manifest's `epic_key` or in `stories`, **or** it
   carries the `run-<RUN_ID>` label. If it doesn't, **refuse and stop**.
3. **Operate from the manifest, not from free-form search.** Act only on the exact
   `epic_key` / `stories` recorded in `.adlc/feature.json` — never infer targets
   from a broad search.
4. **One branch per run** (`feature/<EPIC_KEY>-<slug>`, unique because the epic key
   is); the default branch is never touched (verify-branch before commits). Each
   participant uses **their own repo checkout**, so local work never collides.

Together these turn the naming scheme into *enforced* isolation: parallel runs stay
completely separate in both Jira and Git.

**Feature-branch discipline.** After Step 0, *all* work happens on the feature
branch; **the repo's default branch (`$BASE_BRANCH` — `master`/`main`) is never touched**. Before any commit, the acting agent verifies
the branch:
```bash
[ "$(git rev-parse --abbrev-ref HEAD)" = "$BRANCH" ] || { echo "WRONG BRANCH — abort"; exit 1; }
```

**Roles & tool scopes (why the lead must bridge).**
| Agent | Jira | GitHub / Bash | Does |
|-------|:----:|:-------------:|------|
| **lead** | read + transition | GitHub (no Bash) | orchestrates, drives statuses, reads state |
| **design** | — | Bash + GitHub | wireframes; owns the branch + commits |
| **BA** | author (create/edit/transition) | — | epic + stories + requirements |
| **code** (`<WS>-<repo>`) | — | Bash + GitHub | implements, pushes, PR |
No single agent spans Jira **and** GitHub — so the **lead bridges**: it carries
Jira-authored requirements to the code agent (which can't read Jira) and points it
at the on-branch wireframe (which it can). The bridging is about **remote
systems** — every agent can still **read local files** (e.g. the BA reads the
wireframe HTML straight from the working copy in Step 3).

---

## Workshop Structure

### Session 1 — Design (~60 min)
**Achieve:** a unique epic + feature branch, and a **PO-approved** clickable wireframe.
**Steps:** Pre-flight → 0 (scaffold) → 1 (wireframe) → 2 (PO review).
**Validation:** epic created + labeled; branch exists; wireframe approved, committed & pushed.

### Session 2 — Requirements (~45 min)
**Achieve:** BE/FE/Wireframe **stories** authored from the approved design and set **Ready for Dev**.
**Sequencing:** Session 1 must be complete (requirements are written *against* the approved wireframe).
**Steps:** 3 (BA authors) → 4 (you review).
**Validation:** stories linked to the epic, labeled, Ready for Dev.

### Session 3 — Implementation (~60 min)
**Achieve:** the feature implemented on the branch, a **PR** opened, and reviewed by you.
**Sequencing:** Sessions 1 & 2 must be complete.
**Steps:** 5 (orchestrated implementation — **BE batch → mini-gate → FE batch → full gate**) → 6 (your code review).
**Validation:** code pushed, PR open, stories In Code Review; reach **15/15**.

---

## Detailed Steps

### Orientation — what this is and why (present this FIRST)

> **Facilitator (incl. `workshop-executor`): present this orientation to the learner
> verbatim and get a "ready?" before running Pre-flight. Do not jump into Step 0.**

👋 **Welcome — here's what you're about to do and why.**

**What this workshop teaches.** You'll experience the **Agentic Development
Lifecycle (ADLC)**: how a *team of AI agents* takes a feature from idea to a
reviewed pull request, with a **human in the loop at every decision point** — and
that human is **you**. The goal isn't just to ship the feature; it's to *feel* how
agents collaborate, where they hand off, and where human judgment belongs.

**The process you'll learn (design-first):**
```
   YOU set the task
        │
   ┌────▼─────────┐   ┌──────────────┐   ┌───────────────────┐
   │ 1. DESIGN    │──▶│ 2. REQUIREMENTS│──▶│ 3. IMPLEMENTATION │
   │ wireframe    │   │ BA writes      │   │ code agent builds │
   │ (design agt) │   │ stories (BA)   │   │ → Pull Request    │
   └────┬─────────┘   └──────┬─────────┘   └─────────┬─────────┘
   you approve         you approve            you review
   as PRODUCT OWNER    as BA REVIEWER         as TECH-LEAD
```
- **Agents do the production work** (wireframe, stories, code); a **lead agent
  orchestrates** them.
- **You are the human at all three gates** — Product Owner, BA reviewer, Tech-lead.
- It's **design-first**: you approve *how it looks* before requirements are written,
  and requirements before code.
- It runs in **3 sessions** with natural stop points — you can pause at any gate and
  **resume later**; your progress is saved on disk.

**What you'll build.** A real **time-tracking** feature (projects · time entries ·
hours dashboard) — see the full spec in the **"The feature you'll build (sample
task)"** section above. That section is the single source of truth for the task.

**What you'll walk away knowing:** how agentic delivery works hands-on, how a lead
agent bridges specialists with different tools, and how persistent state lets an
agentic workflow stop and resume.

**Ready to begin?** (yes/no) → on **yes**, continue to Pre-flight.

---

### Pre-flight — gate + identity (before Session 1)

**Why this matters:** this workshop *uses* a configured workspace and writes to a
**shared** Jira + repo. The gate stops you if the workspace isn't ready; the
identity step makes your run unique and isolated so you never collide with another
participant.

**0a. Gate — STOP unless ready** (run from the workspace root). This workshop is
**hard-wired to the `TRRND` Jira project** — the gate includes a TRRND access check:
```bash
[ -d .venv ] && source .venv/bin/activate 2>/dev/null
set -a; . ./.env; set +a
# Detect the repo's DEFAULT branch (master or main) — never hardcode it.
BASE_BRANCH=$(git -C ../src/<repo> symbolic-ref --short refs/remotes/origin/HEAD 2>/dev/null | sed 's#^origin/##')
BASE_BRANCH=${BASE_BRANCH:-$(git -C ../src/<repo> rev-parse --abbrev-ref HEAD)}
echo "default branch: $BASE_BRANCH"
ok=1; chk(){ if eval "$2" >/dev/null 2>&1; then echo "  ✓ $1"; else echo "  ✗ $1"; ok=0; fi; }
chk "7 agents incl. design"            "[ $(ls .claude/agents/*.md | wc -l) -ge 7 ] && ls .claude/agents/*-design.md"
chk "lead has Jira transition"         "grep -q jira_transition_issue .claude/agents/*-lead.md"
chk "repo clean on default branch ($BASE_BRANCH)" "[ \"$(git -C ../src/<repo> rev-parse --abbrev-ref HEAD)\" = \"$BASE_BRANCH\" ] && git -C ../src/<repo> diff --quiet"
chk "can push to repo (dry run)"       "git -C ../src/<repo> push --dry-run origin \"$BASE_BRANCH\""
chk "docker running (Step 5's runtime gate needs it)" "docker info"

# --- Jira: one probe, two checks — PAT valid, then TRRND access (HARD requirement) ---
jprobe(){ python3 -c "import os,ssl,urllib.request as u; c=ssl._create_unverified_context(); u.urlopen(u.Request('https://support.dataart.com/rest/api/2/$1',headers={'Authorization':'Bearer '+os.environ['JIRA_PERSONAL_TOKEN']}),timeout=10,context=c)" >/dev/null 2>&1; }
if jprobe myself; then
  echo "  ✓ Jira reachable (PAT works)"
  if jprobe project/TRRND; then echo "  ✓ access to the TRRND Jira project"; else
    echo "  ✗ access to the TRRND Jira project"
    echo "     ⛔ Please contact the workshop org team to get access to the TRRND project."
    ok=0
  fi
else
  echo "  ✗ Jira reachable (PAT works)"; echo "  ✗ TRRND access (skipped — fix the PAT first)"; ok=0
fi

[ "$ok" = 1 ] && echo "GO ✅  ready to deliver a feature" || echo "STOP ⛔  fix the flagged item(s) above first"
```
**Checkpoint:** ✅ `GO ✅` (all checks pass, including TRRND access).

> **No TRRND access?** The gate prints **"Please contact the workshop org team to get
> access to the TRRND project."** Stop here — you can't run the workshop until you have
> access. (TRRND is the fixed project for this workshop; it is *not* configurable.)

**0b. Identity:**
```bash
set -a; . ./.env; set +a
RUN_ID="${JIRA_USERNAME%%@*}-$(date +%Y%m%d-%H%M%S)-$(printf %04x $RANDOM)"   # e.g. pgladko-20260626-142530-9c1f — seconds+random ⇒ unique even for parallel/same-minute runs
PROJECT_KEY=TRRND                                         # fixed — this workshop uses the TRRND project
echo "RUN_ID = $RUN_ID  |  PROJECT_KEY = $PROJECT_KEY"
```
The project is **always `TRRND`** — there's nothing to choose; the gate already
confirmed your access.

> `RUN_ID` exists only in this shell (and the chat) until Step 0 commits it into
> `.adlc/feature.json` — from that moment the **manifest is the source of truth**.
> Keep this shell open until Step 0 completes.

**Checkpoint:** ✅ `RUN_ID` set; `PROJECT_KEY=TRRND`; access confirmed. **Ready for Session 1?** (yes/no)

---

> ## ▶ Session 1 — Design
> **What you'll achieve:** a unique epic + feature branch and a PO-approved wireframe.
> **Sequencing:** first of three consecutive sessions — finish it before Session 2. Not parallel.

### Step 0: Scaffold the run (lead orchestrates)

**Why this matters:** before any design or code, the run needs a unique, persistent
identity that every later step (and every future session) can anchor on — an empty
epic, a feature branch, and the manifest that ties them together. Get this right and
the rest of the run is resumable and collision-free.

**What happens (you observe the orchestration):**
1. **lead → BA:** create an **empty epic** in **`TRRND`**, summary
   `[ADLC <RUN_ID>] Time tracking`, label `run-<RUN_ID>` → BA returns `<EPIC_KEY>`.
2. **lead → design** (Bash): create and switch to the branch off the repo's **default branch** (auto-detected — `master` or `main`):
   ```bash
   cd ../src/<repo>
   BASE_BRANCH=$(git symbolic-ref --short refs/remotes/origin/HEAD 2>/dev/null | sed 's#^origin/##'); BASE_BRANCH=${BASE_BRANCH:-$(git rev-parse --abbrev-ref HEAD)}
   git checkout "$BASE_BRANCH" && git pull --ff-only
   BRANCH="feature/<EPIC_KEY>-time-tracking"
   git checkout -b "$BRANCH" && git push -u origin "$BRANCH"
   ```
3. **lead → design:** write & commit the manifest `.adlc/feature.json` (run_id,
   project_key, epic_key, branch, base_branch, feature, `current_step: 0`, and
   `timeline["0"]` stamped) and push.

**Your role:** none — just watch the scaffold. Confirm the reported epic key + branch look right.

💡 *Think about it: why did the lead delegate epic creation to the BA instead of
creating the epic itself?* (Tool scopes — the lead can only **read + transition**
Jira; the BA holds the author tools.)

**Checkpoint:** ✅ Empty `<EPIC_KEY>` exists (labeled `run-<RUN_ID>`); branch pushed; manifest committed. Ready for the wireframe? (yes/no)

---

### Step 1: Generate the wireframe (design agent)

**Why this matters:** design-first. Agreeing the *shape* of the feature on a cheap,
reviewable artifact — before requirements or code — catches misunderstandings when
they're free to fix. The agent produces an on-brand mockup so the review is about
substance, not styling.

**What happens:** **lead → design agent:** "produce a clickable HTML wireframe for
the time-tracking feature — a Projects list/create, a Time-entry form (date, hours,
description, billable), and an hours dashboard — grounded in the real
React/Tailwind/shadcn styles. Write it to `wireframes/<EPIC_KEY>.html` on the
branch." The design agent reads the actual `index.css`/components and emits the file
(working copy, **not yet committed** — see Step 2).

**Your role:** none yet — the review is Step 2.

💡 *Think about it: why ground the wireframe in the repo's **real** styles instead
of a generic mockup tool?* (So your PO review judges substance on the product's real
look — and the FE stories later map 1:1 to existing components.)

**Checkpoint:** ✅ `wireframes/<EPIC_KEY>.html` exists in the working copy and opens in a browser. Ready to review it? (yes/no)

---

### Step 2: Product-Owner review of the wireframe — **you decide** (reject loop)

**Why this matters:** this is the **iterate-on-feedback loop** with an agent — the
core of human-in-the-loop design. You hold the product judgment; the agent does the
revising. Committing only the *approved* version keeps git history clean.

**Your role (Product Owner):** open `wireframes/<EPIC_KEY>.html` and review it
against the feature intent *(on WSL:
`explorer.exe "$(wslpath -w wireframes/<EPIC_KEY>.html)"` opens it in your Windows
browser; elsewhere just open the file)*. Then:
- **Reject with comments** → type what to change (e.g. "billable should be a toggle,
  not a checkbox; add an empty-state for no projects"). The **lead relays** your
  comments to the design agent → it **revises the file in place** (no commit) → you
  review again. **Unbounded** — loop until you're happy. Each round is recorded in
  the manifest's `reviews[]`.
- **Approve** → the design agent makes a **single commit** (wireframe + manifest,
  `current_step: 2`) and **pushes** (verify-branch first).

**Checkpoint:** ✅ You approved the wireframe; it's committed & pushed to the branch.

✅ **Session 1 complete!** Unique epic, branch, and an approved design — all
persisted. 💾 **Natural stop point** — you can resume Session 2 later.
**Continue to Session 2, or stop?** (continue / stop)

---

> ## ▶ Session 2 — Requirements
> **What you'll achieve:** BE/FE/Wireframe stories authored from the approved design and set Ready for Dev.
> **Sequencing:** **Session 1 must be complete** — requirements are written *against* the approved wireframe. Never run alongside Session 1.

### Step 3: BA authors the epic + stories (BA agent)

**Why this matters:** now that the *design* is agreed, requirements can be precise.
Watch how an agent decomposes a feature into right-sized, testable stories grounded
in both the product KB and the approved wireframe.

**What happens (the lead points the BA at the design):** the **lead** gives the BA
the feature description and the wireframe's **path in the local working copy**
(`../src/<repo>/wireframes/<EPIC_KEY>.html`). The BA reads the wireframe HTML
**directly with its Read tool** — screens, fields, controls, with no lossy relay
summary in between. **BA →** fills the epic description and
creates **BE / FE / Wireframe stories**, then **explicitly links each one to
`<EPIC_KEY>` by setting the Epic Link field** (see authoring rules — the dedicated
"link to epic" call is unreliable here, so set the field directly), labels them
`run-<RUN_ID>`, and writes acceptance criteria. **Each implementation story's acceptance
criteria include new tests** (so Step 5's gate has something to run, not just static
checks). **Every story summary follows the standard:**
`[ADLC <RUN_ID>] [<AREA>] <title>` (see Naming conventions). As it works it moves each
story to **In Requirements** (the BA-working state), then to **BA Review** when it submits them
for your review.

> **BA authoring rules (from real runs):**
> - **Link every story to the epic — explicitly, by setting the Epic Link field.**
>   After creating a story, attach it to the epic with
>   `jira_update_issue(<STORY_KEY>, fields={}, additional_fields={"customfield_10000": "<EPIC_KEY>"})`.
>   **Verified on this TRRND instance:** the Epic Link field is `customfield_10000`,
>   and the dedicated **`jira_link_to_epic` tool is a silent no-op** (it returns
>   "linked" but the field stays empty) — so **do not use it**. Likewise the Epic
>   Link does **not** stick when passed to `jira_create_issue`. So stories silently
>   land **unparented** unless you set the field in a follow-up `jira_update_issue`.
>   Treat create + link as two steps for every story, and don't advance until the
>   link is confirmed (see the verification below). *(If the field id ever differs,
>   rediscover it with `jira_search_fields("Epic Link")`.)*
> - **Cross-cutting concerns get their own story.** Global navigation / the app
>   shell (sidebar, menu entry) is easy to lose *between* per-screen stories — if
>   the wireframe shows it, the BA must capture it as an explicit story (e.g.
>   `[<AREA=FE>] App navigation / sidebar entry`), not assume it inside a screen story.
> - **Specify tests in the repo's *existing* frameworks only** — `pytest` for
>   backend, **Playwright** for frontend (this repo has **no Vitest/Testing
>   Library**). An acceptance criterion that demands a framework the repo doesn't
>   have is unsatisfiable as written: the code agent must either install new
>   tooling (scope the story never authorized) or fail the AC.
> - **Write Jira descriptions as clean Markdown with real newlines** — Data Center
>   `mcp-atlassian` renders escaped content literally. Use **real line breaks** (not
>   `\n`) and **backticks** for code/labels, **not** `**bold**` inside bullets (it
>   shows the literal `\*\*`).

The BA decides the optimal split — illustratively (for run `pgladko-20260626-142530-9c1f`):
- `[ADLC pgladko-20260626-142530-9c1f] [BE] Project model + CRUD`
- `[ADLC pgladko-20260626-142530-9c1f] [BE] TimeEntry model + CRUD`
- `[ADLC pgladko-20260626-142530-9c1f] [BE] Alembic migration for time-tracking tables`
- `[ADLC pgladko-20260626-142530-9c1f] [BE] Dashboard hours-summary endpoint`
- `[ADLC pgladko-20260626-142530-9c1f] [FE] Projects screen`
- `[ADLC pgladko-20260626-142530-9c1f] [FE] Time-entry form`
- `[ADLC pgladko-20260626-142530-9c1f] [FE] Hours dashboard`
- `[ADLC pgladko-20260626-142530-9c1f] [WF] Time-tracking wireframe`

**Your role:** none yet — the review is Step 4.

**Before the checkpoint, the BA verifies parenting** (catches the silent-unlink
failure): `jira_search` with `"Epic Link" = <EPIC_KEY>` must return **every** story
it just created. Any story missing → re-run the Epic Link update for it
(`jira_update_issue` with `customfield_10000`, per the authoring rules above)
before reporting done.

💡 *Think about it: why does every story need both the `[ADLC <RUN_ID>]` summary
stamp **and** the `run-<RUN_ID>` label?* (Humans group by what they can see — the
summary; agents filter by what they can query — the label.)

**Checkpoint:** ✅ Every story is **linked under `<EPIC_KEY>`** (confirmed by the search above), labeled `run-<RUN_ID>`, status **BA Review**. Ready to review them? (yes/no)

---

### Step 4: Requirements review — **you decide**

**Why this matters:** human judgment on scope and correctness *before* a line of code.
Cheap to change a story; expensive to change a built feature.

**Your role (BA reviewer):** read the stories (the lead can show them via
`jira_search labels = run-<RUN_ID>`). Adjust scope/criteria as needed (ask the BA to
edit), then set each story to **Ready for Dev**. The manifest advances to
`current_step: 5` and records the story keys.

**Checkpoint:** ✅ Stories are **Ready for Dev**.

✅ **Session 2 complete!** Requirements locked. 💾 **Stop point** — resume Session 3 anytime.

> **🤝 Session 2 → 3 handoff (what happens when you resume):** the **code agent
> can't read Jira**, so on entering Session 3 the **lead** reads your Ready-for-Dev
> stories, assembles an **implementation brief** (requirements + acceptance criteria
> + the on-branch wireframe path), shows it to you, and has it **persisted to
> `.adlc/brief.md` on the branch**. Requirements travel via the brief — on disk,
> not just in chat; the design travels via the branch. You'll see the brief before
> implementation starts.

**Continue to Session 3, or stop?** (continue / stop)

---

> ## ▶ Session 3 — Implementation
> **What you'll achieve:** the feature implemented on the branch, a PR opened, reviewed by you.
> **Sequencing:** **run last** — Sessions 1 & 2 must be complete (this builds the approved, Ready-for-Dev work).

### Step 5: Orchestrated implementation (lead → code agent)

**Why this matters:** this is multi-agent orchestration in the open — the lead turns
agreed requirements + design into delegated work, drives the Jira pipeline, and the
code agent builds against patterns it already knows.

**What happens (you observe):**
1. **lead** prereq-checks the manifest + Jira (wireframe approved ✓, stories Ready ✓).
2. **lead** reads the stories — **run-scoped** (`jira_search 'labels = run-<RUN_ID>'`, or the manifest's `stories`) → builds the **implementation brief** → shows it to you. The brief is **persisted to `.adlc/brief.md` on the branch** (the code agent commits it as its first action in step 4 — the lead has no Bash) and recorded in the manifest's `artifacts.brief`. *Why persisted: the brief survives the chat — a resumed session reads it from disk instead of re-deriving it.*
3. **lead** sets the **[BE] stories In DEV** (batch 1 — the [FE] batch starts only
   after the backend mini-gate; the **[WF] story stays at Ready for Dev**: its
   deliverable was completed and approved in Session 1, there is nothing to
   develop) — *after verifying each key is in this run's manifest / carries
   `run-<RUN_ID>`* (it owns transitions).
4. **lead → code agent — Batch 1: backend** (`<WS>-<repo>`): "implement the **[BE]
   stories** following the **Items-module patterns** (SQLModel models, FastAPI CRUD
   routes, Alembic migration). **Ship new `pytest` tests with each story** (the
   repo's BE framework). **One commit per story, commit message starting with its
   story key** (e.g. `TRRND-513: Project model + CRUD`) — keeps the PR navigable
   and lets Jira link the commits to the stories. Stay on `<BRANCH>`; verify-branch
   before commits. **First action: write the brief you were given to
   `.adlc/brief.md` and commit it.**"
5. **🟡 Backend mini-gate (end of Batch 1):** `alembic upgrade head` applies with a
   **single head** (`alembic heads | wc -l` → 1), the app **boots**, and `pytest`
   (new **and** existing) is green. *Red → same fix-loop as the main gate below;
   the [FE] batch does **not** start until this is green.* On green, the code agent
   stamps `timeline["5-be"]` in the manifest and commits — so the batch boundary
   survives a stop/resume.
6. **lead** sets the **[FE] stories In DEV**, then **→ code agent — Batch 2:
   frontend**: "**regenerate the API client with the repo's package manager —
   `bun`, not `npm`** (npm leaves a stray `package-lock.json`) — then implement the
   **[FE] stories** (TanStack Router/Query + React Hook Form + shadcn/ui screens)
   against the wireframe at `wireframes/<EPIC_KEY>.html`. **Ship Playwright tests**
   (the repo's FE framework — there is no Vitest here). Same commit discipline:
   one commit per story, story key first."
7. **🔴 Runtime & integration gate — BEFORE the PR is opened.** *This is the gate
   whose absence let a non-working PR through in a real run.* The code does **not**
   leave the branch until it actually **runs**:
   - **Migrations apply, single head:** `alembic upgrade head` succeeds **and**
     `alembic heads | wc -l` returns **1**. (A new migration's `down_revision` must
     point at the *real* latest head — a second head makes `upgrade head` ambiguous
     and crashes prestart, so the app never boots.)
   - **App boots:** prestart + backend start cleanly (`./scripts/dev.sh` / `docker compose up`).
   - **Feature smoke test (end-to-end):** create a **Project** → log a **TimeEntry**
     → call the **hours-summary/dashboard endpoint as specified in the stories**
     (its exact path is defined there, e.g. `/api/v1/reports/hours-summary`) — it
     returns correct aggregates. (Catches runtime-only bugs static checks miss —
     e.g. `func.case` vs `sqlalchemy.case` 500s.)
   - **Tests + build:** new **and** existing `pytest` pass; the **Playwright** suite
     passes (the repo's FE test framework); the frontend builds; the client is
     regenerated (with `bun`).
   - **"could not verify" is NOT a pass.** If the code agent's sandbox can't run the
     DB/app, **you (or the lead) run this locally** — use the `/run` or `/verify`
     skill — *before* proceeding. The PR does **not** open while anything is red or
     unverified.
   - **Gate failed? Loop — don't proceed.** The lead relays the failing check's
     output to the code agent → it fixes on the branch → **re-run the whole gate**.
     Unbounded, like Step 2's reject loop. Only a fully green gate opens the PR.
8. **code agent:** push → open the **PR** (`feature/<EPIC_KEY>-…` → the manifest's `base_branch`) — **only now that the gate is green**.
9. **lead** sets the implementation stories **In Code Review** (**[WF]** remains at **Ready for Dev**) and records the PR URL in the manifest.

> **Why this gate exists (the lesson).** Static checks — imports resolve, lint
> clean, client generated, existing unit tests green — are **necessary but not
> sufficient**. Runtime/integration defects are *invisible* to them: an Alembic
> head conflict only appears when migrations execute; dynamic ORM misuse only fails
> when the endpoint is called. An agentic pipeline must **run the code** before the
> PR boundary, or "looks review-ready" ≠ "works".

**Your role:** observe the delegation; if the agent reports any check as "could not
verify," **run it yourself locally** and only let the PR open once the app boots and
the smoke test passes.

💡 *Think about it: why must the runtime gate sit **before** the PR rather than
inside code review?* (Reviewers assume a PR runs; runtime defects — migration-head
conflicts, dynamic ORM misuse — are invisible to static review.)

**Checkpoint:** ✅ Migrations apply (single head) · app **boots** · feature smoke test passes · tests green — **then** PR opened and stories **In Code Review**. Ready for the final review? (yes/no)

---

### Step 6: Code review — **you decide** (Tech-lead)

**Why this matters:** humans own the quality gate. The pipeline produced a reviewable
PR; the call to merge is yours.

**Your role (Tech-lead):** the PR is **already runtime-verified** (Step 5's gate:
it boots + the feature smoke test passed), so your review is about **design,
correctness, and criteria coverage** — not "does it run". Review the diff and each
change against its story's acceptance criteria. Use the GitHub PR view (or ask the
lead via `get_pull_request` / `list_pull_request_files`). Approve, or leave comments
for revision.

> Merging is your decision and is effectively post-workshop — for the exercise,
> completing the review is the finish line.

**Checkpoint:** ✅ You reviewed the PR. 🎉 **Feature delivered end-to-end** — mark the pilot:
```bash
artisyn-workspace status mark pilot_task_delivered
```
→ **15/15.**

---

## Validation

**Completion criteria:**
- [ ] Epic `<EPIC_KEY>` exists, labeled `run-<RUN_ID>`, with BE/FE/Wireframe stories linked.
- [ ] Implementation stories ([BE]/[FE]) moved In Requirements → BA Review → Ready for Dev → In DEV → In Code Review; the **[WF] story stopped at Ready for Dev** (its deliverable was approved in Session 1).
- [ ] Branch `feature/<EPIC_KEY>-…` holds the approved wireframe **and** the implementation; the default branch untouched.
- [ ] **The branch actually runs** (verified *before* the PR opened): `alembic upgrade head` applies with a **single head**, the app **boots**, and the feature smoke test (create Project → log TimeEntry → the stories' hours-summary endpoint returns correct aggregates) passes; new + existing tests green.
- [ ] A PR is open from the feature branch (opened only after the runtime gate passed).
- [ ] `.adlc/feature.json` shows all steps done (and the PR URL).

**Acceptance check (run at the end):**
```bash
cd ../src/<repo>
echo "branch:        $(git rev-parse --abbrev-ref HEAD)   (expect feature/<EPIC_KEY>-…)"
echo "wireframe:     $([ -f wireframes/<EPIC_KEY>.html ] && echo present || echo MISSING)"
echo "manifest step: $(python3 -c "import json;print(json.load(open('.adlc/feature.json'))['current_step'])")"
BASE_BRANCH=$(python3 -c "import json;print(json.load(open('.adlc/feature.json'))['base_branch'])")   # the manifest is the source of truth
git log --oneline "$BASE_BRANCH"..HEAD | head   # the run's commits (wireframe + implementation)
# Jira (via the lead/BA): jira_search 'labels = run-<RUN_ID>'  → epic + stories + statuses
```
**Verdict:** delivered if the epic+stories exist and progressed, the branch carries
both wireframe and code, the PR is open, and the manifest reflects it.

---

## Manual cleanup (not a step)

The Jira project and repo are **shared**. When you're done, clean up your run
**manually** so the instance doesn't accumulate: close/delete the epic (`<EPIC_KEY>`
and its `run-<RUN_ID>` stories) and delete the feature branch. (Intentionally left
manual — the workshop never bulk-deletes in a shared instance.)

---

## Next Steps

- Run it again with a feature of your own (swap the sample task at Pre-flight) — see **"Running it again (a second pass)"** above for the reset/isolation steps.
- **Move Step 5's runtime/integration gate into CI** — this repo has no
  `.github/workflows/` yet (the devops KB flagged it). A CI job that runs migrations
  (asserting a single Alembic head), boots the app, and runs the smoke + unit tests
  on every PR makes the gate automatic instead of manual/local.
- Explore deeper orchestration: parallel BE/FE code agents in Step 5.

---

## References

**This workshop builds on:**

**Workshops:**
- `configure-workspace-kb-and-agents` — the prerequisite that produces the 7-agent workspace (design agent + lead Jira) this one depends on.

**Skills:**
- `decompose-epic`, `author-story`, `estimate-story` — the BA's authoring workflows (Step 3).
- `lead-orchestration` — the orchestration model (Steps 0, 5).

**Best Practices:**
- `skills-vs-agents-vs-prompts` — why design/BA/code are *agents* with scoped tools.
- `bootstrap-first` — why a configured workspace is the prerequisite.

**Concepts demonstrated:** state-driven resumability (the manifest), per-run
isolation in shared Jira/repo, feature-branch discipline, and orchestrator-bridges-
tool-scopes delegation.

**Generated:** 2026-06-17
