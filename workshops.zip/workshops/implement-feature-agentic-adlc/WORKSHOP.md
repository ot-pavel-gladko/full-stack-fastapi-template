# Workshop: Implement a Feature with the Agentic Development Lifecycle (ADLC)

**Level:** 02-advanced
**Duration:** ~2.5–3 hours (resumable across sessions)
**Prerequisites:** The **configure-workspace** workshop completed — a configured workspace with **7 agents** (incl. the **design** agent and the **lead with Jira read+transition**), a working Jira PAT, and ≥1 repo checked out.
**Date:** 2026-06-17

---

## Overview

You implement one real product feature **end to end** with a team of agents,
acting as the **human at every decision gate** yourself. The lifecycle is
**design-first**: you mock up and approve the UX *before* requirements are written,
then the requirements drive implementation. You drive nothing by hand that an agent
can do — you review, decide, and unblock.

The point isn't just to ship the feature; it's to **experience how agents
collaborate** — how an orchestrator delegates across specialists with different
tools, how state persists so you can stop and resume, and where human judgment
belongs.

**Learning Outcomes:**
- Run a feature through a **design → requirements → implementation** agentic pipeline with human-in-the-loop gates.
- See **multi-agent orchestration**: a lead delegating to design, BA, and code agents that each have *different* tool scopes — and how the lead bridges them.
- Use a **persistent feature manifest** so the workflow survives you closing the laptop (state-driven, not session-driven, resumability).
- Keep many participants safe in **one shared Jira + repo** via per-run uniqueness and branch discipline.

---

## The feature you'll build (sample task)

> **Add a time-tracking feature to the full-stack-fastapi-template application.**
> Users can create **projects**, log **time entries** against them (date, hours,
> description, billable flag), and view a **dashboard** summarizing hours worked.
> Follow the existing **Items module** patterns — backend (SQLModel, FastAPI CRUD,
> Alembic migrations) and frontend (TanStack Router/Query, React Hook Form,
> shadcn/ui). **Keep it simple:** no approval workflows, invoicing, CSV export, or
> timer/stopwatch.

Two new entities (**Project**, **TimeEntry**) + a summary dashboard — enough to
exercise backend, frontend, and a wireframe.

---

## Prerequisites

**Required:**
- The **configure-workspace** workshop finished — verify with `artisyn-workspace status` (≥13/15) and that `.claude/agents/` has **7** agents including `<WS>-design`.
- The lead agent has Jira **read + transition** tools; the BA has the Jira **author** set.
- `JIRA_PERSONAL_TOKEN` + `JIRA_USERNAME` set in `.env`; Jira reachable.
- A clean repo checkout under `../src` on `main`, and the ability to **push** to it.

**Recommended:**
- Familiarity with the repo's Items module (the patterns you'll mirror).

**Setup:**
- `source .venv/bin/activate`; confirm `git`, `uvx`, and the GitHub MCP are working.
- Restart Claude Code once so the Jira MCP server is connected (`/mcp` shows `atlassian-da-jira`).

---

## Conventions & placeholders

Run by many people against the **same** Jira and repo — so everything is scoped
per-run. Substitute `<…>` with your values.

| Placeholder | Meaning | Source |
|---|---|---|
| `<WS>` | Your workspace agent prefix | the `name=` prefix in `.claude/agents/` |
| `<repo>` | Repo dir name | the folder under `../src/` |
| `RUN_ID` | Your unique run id | `<jira-username>-<YYYYMMDD-HHMM>` (auto-derived at Step 0) |
| `<PROJECT_KEY>` | Jira project for the epic/stories | **you choose at Step 0** (e.g. `TRAIN`, `SANDBOX`) |
| `<EPIC_KEY>` | The epic's Jira key | assigned by Jira when the epic is created (e.g. `TRAIN-512`) |

> All commands run from your **workspace root**. The repo working copy is under `../src/<repo>`.

---

## How this workshop runs

A **guided, hands-on, design-first** workshop facilitated by you (or the
`workshop-executor` skill):

1. **Why first.** Every step opens with **Why this matters** — read it before acting.
2. **You are the human at every gate** — Product Owner (wireframe), BA reviewer (requirements), Tech-lead (code). The agents do the production work; you review and decide.
3. **You observe the orchestration.** When the lead delegates, you see *what* it passes to which agent and *why* — that transparency is the lesson.
4. **Stop anytime at a gate.** Sessions break at human reviews; the feature manifest lets you resume later from exactly where you left off.
5. **Sessions run consecutively, never in parallel** — each depends on the last (requirements depend on the approved design; implementation depends on Ready-for-Sprint stories).

> **Facilitator note (incl. `workshop-executor`):** present each step's **Why this
> matters**, the delegation brief, and **Checkpoint** verbatim; pause for the
> learner to review/decide at every human gate; never approve on the learner's behalf.

---

## Concepts (read first — the machinery, and why)

**The feature manifest — `.adlc/feature.json` (state-driven resumability).**
A small JSON file committed to the feature branch that *is* the source of truth for
the run. Any session reads it to know where you are. *Why: a chat session's context
evaporates; the feature's own persisted state does not — so you (or a teammate) can
resume next week.*
```json
{
  "run_id": "pgladko-20260617-1130",
  "project_key": "TRAIN",
  "epic_key": "TRAIN-512",
  "branch": "feature/TRAIN-512-time-tracking",
  "feature": "time tracking",
  "current_step": 3,
  "stories": ["TRAIN-513", "…"],
  "artifacts": { "wireframe": "wireframes/TRAIN-512.html", "pr": null },
  "reviews": []
}
```

**Uniqueness in a shared Jira + repo.** Jira keys are auto-unique; the risks are
*indistinguishability* and *editing someone else's work*. So every run is stamped:
the epic + stories carry a **`run-<RUN_ID>` label**, and the branch is
**`feature/<EPIC_KEY>-<slug>`** (unique because the epic key is). Agents scope every
Jira read to `labels = run-<RUN_ID>` and **never** touch issues outside this run.

**Feature-branch discipline.** After Step 0, *all* work happens on the feature
branch; **`main` is never touched**. Before any commit, the acting agent verifies
the branch:
```bash
[ "$(git rev-parse --abbrev-ref HEAD)" = "$BRANCH" ] || { echo "WRONG BRANCH — abort"; exit 1; }
```

**Roles & tool scopes (why the lead must bridge).**
| Agent | Jira | GitHub / Bash | Does |
|-------|:----:|:-------------:|------|
| **lead** | read + transition | GitHub (no Bash) | orchestrates, drives statuses, reads state |
| **design** | — | Bash + GitHub | wireframes; owns the branch + commits |
| **BA** | author (create/edit/transition) | — | epic + stories + requirements |
| **code** (`<WS>-<repo>`) | — | Bash + GitHub | implements, pushes, PR |
No single agent spans Jira **and** GitHub — so the **lead bridges**: it carries
Jira-authored requirements to the code agent (which can't read Jira) and points it
at the on-branch wireframe (which it can).

---

## Workshop Structure

### Session 1 — Design (~60 min)
**Achieve:** a unique epic + feature branch, and a **PO-approved** clickable wireframe.
**Steps:** Pre-flight → 0 (scaffold) → 1 (wireframe) → 2 (PO review).
**Validation:** epic created + labeled; branch exists; wireframe approved, committed & pushed.

### Session 2 — Requirements (~45 min)
**Achieve:** BE/FE/Wireframe **stories** authored from the approved design and set **Ready for Sprint**.
**Sequencing:** Session 1 must be complete (requirements are written *against* the approved wireframe).
**Steps:** 3 (BA authors) → 4 (you review).
**Validation:** stories linked to the epic, labeled, Ready for Sprint.

### Session 3 — Implementation (~60 min)
**Achieve:** the feature implemented on the branch, a **PR** opened, and reviewed by you.
**Sequencing:** Sessions 1 & 2 must be complete.
**Steps:** 5 (orchestrated implementation) → 6 (your code review).
**Validation:** code pushed, PR open, stories In Review; reach **15/15**.

---

## Detailed Steps

### Orientation — what this is and why (present this FIRST)

> **Facilitator (incl. `workshop-executor`): present this orientation to the learner
> verbatim and get a "ready?" before running Pre-flight. Do not jump into Step 0.**

👋 **Welcome — here's what you're about to do and why.**

**What this workshop teaches.** You'll experience the **Agentic Development
Lifecycle (ADLC)**: how a *team of AI agents* takes a feature from idea to a
reviewed pull request, with a **human in the loop at every decision point** — and
that human is **you**. The goal isn't just to ship the feature; it's to *feel* how
agents collaborate, where they hand off, and where human judgment belongs.

**The process you'll learn (design-first):**
```
   YOU set the task
        │
   ┌────▼─────────┐   ┌──────────────┐   ┌───────────────────┐
   │ 1. DESIGN    │──▶│ 2. REQUIREMENTS│──▶│ 3. IMPLEMENTATION │
   │ wireframe    │   │ BA writes      │   │ code agent builds │
   │ (design agt) │   │ stories (BA)   │   │ → Pull Request    │
   └────┬─────────┘   └──────┬─────────┘   └─────────┬─────────┘
   you approve         you approve            you review
   as PRODUCT OWNER    as BA REVIEWER         as TECH-LEAD
```
- **Agents do the production work** (wireframe, stories, code); a **lead agent
  orchestrates** them.
- **You are the human at all three gates** — Product Owner, BA reviewer, Tech-lead.
- It's **design-first**: you approve *how it looks* before requirements are written,
  and requirements before code.
- It runs in **3 sessions** with natural stop points — you can pause at any gate and
  **resume later**; your progress is saved on disk.

**What you'll build.** A real feature in the full-stack app:
> **Time tracking** — users create **projects**, log **time entries** (date, hours,
> description, billable), and see a **dashboard** of hours worked. Built to mirror
> the existing Items module (backend + frontend). Kept simple — no approvals,
> invoicing, export, or timers.

**What you'll walk away knowing:** how agentic delivery works hands-on, how a lead
agent bridges specialists with different tools, and how persistent state lets an
agentic workflow stop and resume.

**Ready to begin?** (yes/no) → on **yes**, continue to Pre-flight.

---

### Pre-flight — gate + identity (before Session 1)

**Why this matters:** this workshop *uses* a configured workspace and writes to a
**shared** Jira + repo. The gate stops you if the workspace isn't ready; the
identity step makes your run unique and isolated so you never collide with another
participant.

**0a. Gate — STOP unless ready** (run from the workspace root):
```bash
[ -d .venv ] && source .venv/bin/activate 2>/dev/null
ok=1; chk(){ if eval "$2" >/dev/null 2>&1; then echo "  ✓ $1"; else echo "  ✗ $1"; ok=0; fi; }
chk "7 agents incl. design"            "[ $(ls .claude/agents/*.md | wc -l) -ge 7 ] && ls .claude/agents/*-design.md"
chk "lead has Jira transition"         "grep -q jira_transition_issue .claude/agents/*-lead.md"
chk "Jira reachable (PAT works)"       "set -a; . ./.env; set +a; python3 -c \"import os,ssl,urllib.request as u; c=ssl._create_unverified_context(); u.urlopen(u.Request('https://support.dataart.com/rest/api/2/myself',headers={'Authorization':'Bearer '+os.environ['JIRA_PERSONAL_TOKEN']}),timeout=10,context=c)\""
chk "repo clean on main"               "cd ../src/<repo> && [ \"$(git rev-parse --abbrev-ref HEAD)\" = main ] && git diff --quiet"
chk "can push to repo (dry run)"       "cd ../src/<repo> && git push --dry-run origin main"
[ "$ok" = 1 ] && echo "GO ✅  ready to deliver a feature" || echo "STOP ⛔  finish the configure-workspace workshop / fix the flagged item first"
```
**Checkpoint:** ✅ `GO ✅`.

**0b. Identity + project key:**
```bash
set -a; . ./.env; set +a
RUN_ID="${JIRA_USERNAME%%@*}-$(date +%Y%m%d-%H%M)"        # e.g. pgladko-20260617-1130
echo "RUN_ID = $RUN_ID"
```
Then **choose your Jira project key** (the workshop prompts you):
> *"Which Jira project should your epic + stories go in?"* — e.g. `TRAIN`. Unsure?
> ask the lead to run `jira_get_agile_boards` to list projects you can access.

Validate access before proceeding (fail fast):
```
lead/BA → jira_search  JQL: project = <PROJECT_KEY>     # errors = no access → pick another
```
**Checkpoint:** ✅ `RUN_ID` set; `<PROJECT_KEY>` validated. **Ready for Session 1?** (yes/no)

---

> ## ▶ Session 1 — Design
> **What you'll achieve:** a unique epic + feature branch and a PO-approved wireframe.
> **Sequencing:** first of three consecutive sessions — finish it before Session 2. Not parallel.

### Step 0: Scaffold the run (lead orchestrates)

**Why this matters:** before any design or code, the run needs a unique, persistent
identity that every later step (and every future session) can anchor on — an empty
epic, a feature branch, and the manifest that ties them together. Get this right and
the rest of the run is resumable and collision-free.

**What happens (you observe the orchestration):**
1. **lead → BA:** create an **empty epic** in `<PROJECT_KEY>`, summary
   `[ADLC <RUN_ID>] Time tracking`, label `run-<RUN_ID>` → BA returns `<EPIC_KEY>`.
2. **lead → design** (Bash): create and switch to the branch off `main`:
   ```bash
   cd ../src/<repo> && git checkout main && git pull --ff-only
   BRANCH="feature/<EPIC_KEY>-time-tracking"
   git checkout -b "$BRANCH" && git push -u origin "$BRANCH"
   ```
3. **lead → design:** write & commit the manifest `.adlc/feature.json` (run_id,
   project_key, epic_key, branch, feature, `current_step: 0`) and push.

**Your role:** none — just watch the scaffold. Confirm the reported epic key + branch look right.

**Checkpoint:** ✅ Empty `<EPIC_KEY>` exists (labeled `run-<RUN_ID>`); branch pushed; manifest committed. Ready for the wireframe? (yes/no)

---

### Step 1: Generate the wireframe (design agent)

**Why this matters:** design-first. Agreeing the *shape* of the feature on a cheap,
reviewable artifact — before requirements or code — catches misunderstandings when
they're free to fix. The agent produces an on-brand mockup so the review is about
substance, not styling.

**What happens:** **lead → design agent:** "produce a clickable HTML wireframe for
the time-tracking feature — a Projects list/create, a Time-entry form (date, hours,
description, billable), and an hours dashboard — grounded in the real
React/Tailwind/shadcn styles. Write it to `wireframes/<EPIC_KEY>.html` on the
branch." The design agent reads the actual `index.css`/components and emits the file
(working copy, **not yet committed** — see Step 2).

**Your role:** none yet — the review is Step 2.

**Checkpoint:** ✅ `wireframes/<EPIC_KEY>.html` exists in the working copy and opens in a browser. Ready to review it? (yes/no)

---

### Step 2: Product-Owner review of the wireframe — **you decide** (reject loop)

**Why this matters:** this is the **iterate-on-feedback loop** with an agent — the
core of human-in-the-loop design. You hold the product judgment; the agent does the
revising. Committing only the *approved* version keeps git history clean.

**Your role (Product Owner):** open `wireframes/<EPIC_KEY>.html` and review it
against the feature intent. Then:
- **Reject with comments** → type what to change (e.g. "billable should be a toggle,
  not a checkbox; add an empty-state for no projects"). The **lead relays** your
  comments to the design agent → it **revises the file in place** (no commit) → you
  review again. **Unbounded** — loop until you're happy. Each round is recorded in
  the manifest's `reviews[]`.
- **Approve** → the design agent makes a **single commit** (wireframe + manifest,
  `current_step: 2`) and **pushes** (verify-branch first).

**Checkpoint:** ✅ You approved the wireframe; it's committed & pushed to the branch.

✅ **Session 1 complete!** Unique epic, branch, and an approved design — all
persisted. 💾 **Natural stop point** — you can resume Session 2 later.
**Continue to Session 2, or stop?** (continue / stop)

---

> ## ▶ Session 2 — Requirements
> **What you'll achieve:** BE/FE/Wireframe stories authored from the approved design and set Ready for Sprint.
> **Sequencing:** **Session 1 must be complete** — requirements are written *against* the approved wireframe. Never run alongside Session 1.

### Step 3: BA authors the epic + stories (BA agent)

**Why this matters:** now that the *design* is agreed, requirements can be precise.
Watch how an agent decomposes a feature into right-sized, testable stories grounded
in both the product KB and the approved wireframe.

**What happens (the lead bridges the design → BA):** the **lead** points the BA at
the approved wireframe (path + a summary of its screens/fields, since the BA can't
read the branch) and the feature description. **BA →** fills the epic description and
creates **BE / FE / Wireframe stories** (each linked to `<EPIC_KEY>`, labeled
`run-<RUN_ID>`), with acceptance criteria, then sets each to **BA Review**. The BA
decides the optimal split — illustratively:
- **BE:** Project model + CRUD · TimeEntry model + CRUD · Alembic migration · dashboard-summary endpoint
- **FE:** Projects screen · Time-entry form · Dashboard screen
- **Wireframe:** the approved mockup (reference)

**Your role:** none yet — the review is Step 4.

**Checkpoint:** ✅ Stories created under `<EPIC_KEY>`, labeled `run-<RUN_ID>`, status **BA Review**. Ready to review them? (yes/no)

---

### Step 4: Requirements review — **you decide**

**Why this matters:** human judgment on scope and correctness *before* a line of code.
Cheap to change a story; expensive to change a built feature.

**Your role (BA reviewer):** read the stories (the lead can show them via
`jira_search labels = run-<RUN_ID>`). Adjust scope/criteria as needed (ask the BA to
edit), then set each story to **Ready for Sprint**. The manifest advances to
`current_step: 5` and records the story keys.

**Checkpoint:** ✅ Stories are **Ready for Sprint**.

✅ **Session 2 complete!** Requirements locked. 💾 **Stop point** — resume Session 3 anytime.

> **🤝 Session 2 → 3 handoff (what happens when you resume):** the **code agent
> can't read Jira**, so on entering Session 3 the **lead** reads your Ready-for-Sprint
> stories, assembles an **implementation brief** (requirements + acceptance criteria
> + the on-branch wireframe path), and delegates that to the code agent. Requirements
> travel via the lead's relay; the design travels via the branch. You'll see the
> brief before implementation starts.

**Continue to Session 3, or stop?** (continue / stop)

---

> ## ▶ Session 3 — Implementation
> **What you'll achieve:** the feature implemented on the branch, a PR opened, reviewed by you.
> **Sequencing:** **run last** — Sessions 1 & 2 must be complete (this builds the approved, Ready-for-Sprint work).

### Step 5: Orchestrated implementation (lead → code agent)

**Why this matters:** this is multi-agent orchestration in the open — the lead turns
agreed requirements + design into delegated work, drives the Jira pipeline, and the
code agent builds against patterns it already knows.

**What happens (you observe):**
1. **lead** prereq-checks the manifest + Jira (wireframe approved ✓, stories Ready ✓).
2. **lead** reads the stories → builds the **implementation brief** → shows it to you.
3. **lead** sets the stories **In Progress** (it owns transitions).
4. **lead → code agent** (`<WS>-<repo>`): "implement these stories following the
   **Items-module patterns** (SQLModel models, FastAPI CRUD routes, Alembic
   migration; TanStack Router/Query + React Hook Form + shadcn/ui screens). Use the
   wireframe at `wireframes/<EPIC_KEY>.html`. Stay on `<BRANCH>`; verify-branch
   before commits."
5. **code agent:** implements backend + frontend → pushes to the feature branch →
   opens a **PR** (`feature/<EPIC_KEY>-… → main`).
6. **lead** sets the stories **In Review** and records the PR URL in the manifest.

**Your role:** observe the delegation; you can ask the lead to clarify the brief, but the building is the agents' job.

**Checkpoint:** ✅ Code pushed to the branch; **PR opened**; stories **In Review**. Ready for the final review? (yes/no)

---

### Step 6: Code review — **you decide** (Tech-lead)

**Why this matters:** humans own the quality gate. The pipeline produced a reviewable
PR; the call to merge is yours.

**Your role (Tech-lead):** review the PR — the diff, and each change against its
story's acceptance criteria. Use the GitHub PR view (or ask the lead via
`get_pull_request` / `list_pull_request_files`). Approve, or leave comments for
revision.

> Merging is your decision and is effectively post-workshop — for the exercise,
> completing the review is the finish line.

**Checkpoint:** ✅ You reviewed the PR. 🎉 **Feature delivered end-to-end** — mark the pilot:
```bash
artisyn-workspace status mark pilot_task_delivered
```
→ **15/15.**

---

## Validation

**Completion criteria:**
- [ ] Epic `<EPIC_KEY>` exists, labeled `run-<RUN_ID>`, with BE/FE/Wireframe stories linked.
- [ ] Stories moved BA Review → Ready for Sprint → In Progress → In Review.
- [ ] Branch `feature/<EPIC_KEY>-…` holds the approved wireframe **and** the implementation; `main` untouched.
- [ ] A PR is open from the feature branch.
- [ ] `.adlc/feature.json` shows all steps done (and the PR URL).

**Acceptance check (run at the end):**
```bash
cd ../src/<repo>
echo "branch:        $(git rev-parse --abbrev-ref HEAD)   (expect feature/<EPIC_KEY>-…)"
echo "wireframe:     $([ -f wireframes/<EPIC_KEY>.html ] && echo present || echo MISSING)"
echo "manifest step: $(python3 -c "import json;print(json.load(open('.adlc/feature.json'))['current_step'])")"
git log --oneline main..HEAD | head        # the run's commits (wireframe + implementation)
# Jira (via the lead/BA): jira_search 'labels = run-<RUN_ID>'  → epic + stories + statuses
```
**Verdict:** delivered if the epic+stories exist and progressed, the branch carries
both wireframe and code, the PR is open, and the manifest reflects it.

---

## Manual cleanup (not a step)

The Jira project and repo are **shared**. When you're done, clean up your run
**manually** so the instance doesn't accumulate: close/delete the epic (`<EPIC_KEY>`
and its `run-<RUN_ID>` stories) and delete the feature branch. (Intentionally left
manual — the workshop never bulk-deletes in a shared instance.)

---

## Next Steps

- Run it again with a feature of your own (swap the sample task at Pre-flight).
- Add a QA or reviewer agent and insert an automated-test gate before Step 6.
- Explore deeper orchestration: parallel BE/FE code agents in Step 5.

---

## References

**This workshop builds on:**

**Workshops:**
- `configure-workspace-kb-and-agents` — the prerequisite that produces the 7-agent workspace (design agent + lead Jira) this one depends on.

**Skills:**
- `decompose-epic`, `author-story`, `estimate-story` — the BA's authoring workflows (Step 3).
- `lead-orchestration` — the orchestration model (Steps 0, 5).

**Best Practices:**
- `skills-vs-agents-vs-prompts` — why design/BA/code are *agents* with scoped tools.
- `bootstrap-first` — why a configured workspace is the prerequisite.

**Concepts demonstrated:** state-driven resumability (the manifest), per-run
isolation in shared Jira/repo, feature-branch discipline, and orchestrator-bridges-
tool-scopes delegation.

**Generated:** 2026-06-17
