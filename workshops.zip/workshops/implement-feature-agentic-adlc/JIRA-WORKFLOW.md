# Jira workflow for this workshop (Story lifecycle) — TRRND

This workshop is **hard-wired to the `TRRND` Jira project** and drives **Story**
issues through a fixed lifecycle. The workflow below is **configured and verified
in TRRND** (tested end-to-end on 2026-06-25 — a probe Story walked the full chain).

The agents only **transition** issues (`jira_transition_issue`, after discovering
available transitions with `jira_get_transitions`) — they don't edit workflows. If
the workflow ever changes, re-verify and update this file + the workshop's status
names so they match exactly.

## Story lifecycle (as configured in TRRND)

```
Open ─(start BA)─▶ In Requirements ─(Start BA review)─▶ BA Review
     ─(start Ready for Dev)─▶ Ready for Dev ─(start DEV)─▶ In DEV
     ─(Start Code Review)─▶ In Code Review
```

| # | Status | Meaning | Set by | Workshop step |
|---|--------|---------|--------|---------------|
| 0 | `Open` | created | Jira on create | 3 (BA creates) |
| 1 | **`In Requirements`** | BA agent drafting requirements (BA-working) | BA agent | 3 (start) |
| 2 | **`BA Review`** | BA done; awaiting human requirements review | BA agent | 3 (submit) |
| 3 | **`Ready for Dev`** | requirements approved; queued for dev | human (BA reviewer) | 4 |
| 4 | **`In DEV`** | code agent implementing | lead | 5.0 |
| 5 | **`In Code Review`** | PR under code review | lead | 5.4 |

## Transitions (as configured)

| Transition name | From → To | Triggered by |
|-----------------|-----------|--------------|
| `start BA` | `Open` → `In Requirements` | BA (Step 3) |
| `Start BA review` | `In Requirements` → `BA Review` | BA (Step 3) |
| `start Ready for Dev` | `BA Review` → `Ready for Dev` | human (Step 4) |
| `start DEV` | `Ready for Dev` → `In DEV` | lead (Step 5.0) |
| `Start Code Review` | `In DEV` → `In Code Review` | lead (Step 5.4) |

Backward transitions also exist (e.g. `Stop BA`, `Stop BA review`, `Stop DEV`) for
sending work back; the workshop doesn't require them.

> **The workshop's status names match these exactly.** Agents discover the right
> transition at runtime via `jira_get_transitions` (transition names are
> intent-clear), so the chain runs without hardcoded transition IDs.

## Linking stories to the epic (Epic Link)

The BA must **parent every story under the run's epic**, and on this Data Center
instance there is exactly one reliable way to do it:

- **Use:** `jira_update_issue(<STORY_KEY>, fields={}, additional_fields={"customfield_10000": "<EPIC_KEY>"})`.
  `customfield_10000` is the **"Epic Link"** field on TRRND (verified
  2026-06-30 via `jira_search_fields("Epic Link")` → `customfield_10000`,
  `com.pyxis.greenhopper.jira:gh-epic-link`).
- **Do NOT use** `jira_link_to_epic` — on TRRND it **returns a success message but
  does not set the field** (silent no-op; verified 2026-06-30). Stories stay
  unparented.
- The Epic Link also does **not** stick when passed into `jira_create_issue`, so
  create-then-link is **two steps**.
- **Verify** with JQL `"Epic Link" = <EPIC_KEY>` — it must return every story.
  (Reading `customfield_10000` back via `jira_get_issue` can show `{"value": null}`
  as a serialization artifact even when set — trust the JQL.)

## Notes

- The classic-default statuses `In Progress`, `Resolved`, `Reopened`, `Closed` still
  exist but are **unused** by the workshop (it ends at `In Code Review`; merge/close
  is post-workshop).
- Minor: `In Requirements` and `In DEV` are mapped to the **To Do** status category;
  consider moving `In DEV` to *In Progress* for board accuracy (cosmetic — does not
  affect the workshop).

## Re-verify after any workflow change

```
# Create a test Story in TRRND, then walk it:
jira_get_transitions <STORY-KEY>     # from Open → expect "start BA"
# transition through the chain, confirming each next status; then delete the test story.
```
